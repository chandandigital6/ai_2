<style>
    .ai-hero {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 24px;
        padding: 32px;
        border-radius: 20px;
        background: linear-gradient(115deg, #103d36, #245852);
        color: #fff;
        margin: 22px 0
    }

    .ai-eyebrow {
        font-size: 11px;
        letter-spacing: .14em;
        color: #aee9ce
    }

    .ai-hero h2 {
        font-size: clamp(24px, 3vw, 36px);
        line-height: 1.2;
        margin: 12px 0;
        font-weight: 750
    }

    .ai-hero p {
        max-width: 620px;
        line-height: 1.6;
        opacity: .85
    }

    .ai-balance {
        min-width: 160px;
        text-align: center;
        border: 1px solid #ffffff40;
        border-radius: 16px;
        padding: 20px
    }

    .ai-balance strong {
        font-size: 42px;
        display: block
    }

    .ai-balance span,
    .ai-balance small {
        display: block;
        font-size: 12px
    }

    .ai-steps a {
        border: 1px solid #d0ded9;
        border-radius: 9px;
        padding: 10px;
        font-size: 13px
    }

    .ai-plan,
    .ai-result {
        padding: 20px;
        border: 1px solid #d4e1dc;
        border-radius: 14px;
        min-width: 0
    }

    .ai-plan h3,
    .ai-result h3,
    .ai-subtitle {
        font-size: 17px;
        font-weight: 700;
        margin-bottom: 10px
    }

    .ai-subtitle {
        margin-top: 22px
    }

    .ai-price {
        font-size: 28px;
        font-weight: 750;
        color: #27715c;
        margin: 12px 0
    }

    .ai-plan ul {
        padding-left: 18px;
        list-style: disc;
        font-size: 13px;
        line-height: 1.9;
        margin: 12px 0
    }

    .ai-warning {
        padding: 14px 18px;
        background: #fff4db;
        color: #734a08;
        border: 1px solid #efd6a5;
        border-radius: 10px;
        font-size: 13px;
        margin: 16px 0
    }

    .ai-error {
        color: #bd3037;
        font-size: 13px;
        line-height: 1.6;
        white-space: pre-line;
        margin: 10px 0
    }

    .ai-toast {
        position: fixed;
        right: 22px;
        top: 22px;
        z-index: 99999;
        max-width: min(450px, calc(100vw - 44px));
        background: #164e3f;
        color: white;
        padding: 16px 20px;
        border-radius: 12px;
        box-shadow: 0 10px 30px #0003;
        white-space: pre-line
    }

    .ai-toast[data-error=true] {
        background: #922e35
    }

    .ai-toast[hidden] {
        display: none
    }

    .ai-check {
        display: inline-flex;
        gap: 7px;
        align-items: center;
        margin: 10px 16px 12px 0;
        font-size: 13px
    }

    .ai-preview {
        display: block;
        max-width: 100%;
        max-height: 520px;
        object-fit: contain;
        border-radius: 12px;
        margin: 16px auto
    }

    .ai-asset img {
        width: 100%;
        height: 150px;
        object-fit: contain;
        border: 1px solid #dce6e3;
        border-radius: 12px;
        background: #fff
    }

    .ai-asset p {
        font-size: 13px;
        margin: 10px 0
    }

    .ai-result details {
        margin-top: 14px
    }

    .ai-result .ex-output {
        overflow-wrap: anywhere
    }

    .ai-result {
        margin-top: 12px
    }

    button:disabled {
        opacity: .55;
        cursor: wait
    }

    summary {
        cursor: pointer;
        font-size: 13px;
        padding: 12px 0
    }

    html {
        scroll-behavior: smooth
    }

    @media(max-width:640px) {
        .ai-hero {
            flex-direction: column;
            align-items: stretch;
            padding: 22px
        }

        .ai-balance {
            text-align: left
        }

        .ai-balance strong {
            font-size: 32px
        }

        .ai-plan,
        .ai-result {
            padding: 15px
        }
    }
</style>
